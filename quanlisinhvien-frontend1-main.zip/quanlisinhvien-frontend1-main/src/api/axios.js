import axios from 'axios';

/**
 * Tạo một instance axios đã cấu hình sẵn:
 * - baseURL: địa chỉ backend Spring Boot
 * - Tự động gắn JWT token vào mỗi request
 */
const api = axios.create({
  baseURL: 'http://localhost:8080',
});

// Interceptor: chạy trước mỗi request để gắn token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token'); // lấy token đã lưu khi đăng nhập
  if (token) {
    config.headers.Authorization = `Bearer ${token}`; // gắn vào header
  }
  return config;
});

export default api;
