import api from './axios';

/**
 * Gọi API đăng nhập.
 * @param {string} username
 * @param {string} password
 * @returns Promise<{ token, username, role }>
 */
export const login = (username, password) =>
  api.post('/api/auth/login', { username, password });
