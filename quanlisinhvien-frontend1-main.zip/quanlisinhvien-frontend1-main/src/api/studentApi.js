import api from './axios';

/**
 * Các hàm gọi API sinh viên.
 * Mỗi hàm trả về Promise → dùng async/await bên ngoài.
 */

// Lấy danh sách tất cả sinh viên
export const getStudents = () => api.get('/api/students');

// Thêm mới sinh viên (chỉ ADMIN)
export const createStudent = (data) => api.post('/api/students', data);

// Sửa sinh viên theo id (ADMIN & USER)
export const updateStudent = (id, data) => api.put(`/api/students/${id}`, data);

// ── CÁC API QUẢN LÝ ĐIỂM (GRADE) ──
// Thêm môn học mới cho sinh viên (chỉ ADMIN)
export const addStudentGrade = (studentId, data) => api.post(`/api/grades/student/${studentId}`, data);

// Sửa điểm/tên môn học (chỉ ADMIN)
export const updateGrade = (gradeId, data) => api.put(`/api/grades/${gradeId}`, data);

// Xóa môn học (chỉ ADMIN)
export const deleteGrade = (gradeId) => api.delete(`/api/grades/${gradeId}`);

// Xóa sinh viên theo id (chỉ ADMIN)
export const deleteStudent = (id) => api.delete(`/api/students/${id}`);