import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import StudentList from './pages/StudentList';

/**
 * Component gốc của ứng dụng.
 * Định nghĩa các route (đường dẫn) của app:
 *   /login    → Trang đăng nhập
 *   /students → Trang danh sách sinh viên (phải đăng nhập)
 *   /         → Tự redirect về /students
 */
function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Trang đăng nhập - ai cũng vào được */}
        <Route path="/login" element={<Login />} />

        {/* Trang sinh viên - phải có token thì mới vào */}
        <Route
          path="/students"
          element={
            localStorage.getItem('token')
              ? <StudentList />
              : <Navigate to="/login" />
          }
        />

        {/* Mặc định: chuyển về /students */}
        <Route path="*" element={<Navigate to="/students" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;