import React from 'react';

function StudentTable({ students, searchTerm, isAdmin, onEdit, onDelete, onGrade }) {
  if (students.length === 0) {
    return (
      <table className="student-table">
        <thead>
          <tr>
            <th>#</th><th>Mã SV</th><th>Họ và tên</th><th>Ngày sinh</th>
            <th>Lớp</th><th>Ngành</th><th>Điện thoại</th><th>Địa chỉ</th>
            <th>Số môn</th><th>Hành động</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td colSpan={10} style={{ textAlign: 'center', color: '#9ca3af', padding: '24px' }}>
              {searchTerm ? 'Không tìm thấy sinh viên phù hợp.' : 'Chưa có dữ liệu.'}
            </td>
          </tr>
        </tbody>
      </table>
    );
  }

  return (
    <table className="student-table">
      <thead>
        <tr>
          <th>#</th><th>Mã SV</th><th>Họ và tên</th><th>Ngày sinh</th>
          <th>Lớp</th><th>Ngành</th><th>Điện thoại</th><th>Địa chỉ</th>
          <th>Số môn</th><th>Hành động</th>
        </tr>
      </thead>
      <tbody>
        {students.map((sv, index) => (
          <tr key={sv.id}>
            <td style={{ color: '#9ca3af' }}>{index + 1}</td>
            <td><strong>{sv.studentCode}</strong></td>
            <td>{sv.fullName}</td>
            <td>{sv.dateOfBirth ? new Date(sv.dateOfBirth).toLocaleDateString('vi-VN') : '—'}</td>
            <td>{sv.className || '—'}</td>
            <td>{sv.major || '—'}</td>
            <td>{sv.phone || '—'}</td>
            <td>{sv.address || '—'}</td>
            <td>{sv.grades ? sv.grades.length : 0} môn</td>
            <td>
              <div style={{ display: 'flex', gap: '6px' }}>
                <button className="btn-edit" onClick={() => onGrade(sv)}>
                  {isAdmin ? 'Điểm' : 'Xem điểm'}
                </button>
                <button className="btn-edit" onClick={() => onEdit(sv)}>Sửa</button>
                {isAdmin && (
                  <button className="btn-delete" onClick={() => onDelete(sv.id, sv.fullName)}>Xóa</button>
                )}
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default StudentTable;
