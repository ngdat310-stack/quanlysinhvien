import React from 'react';

function StudentModal({ editId, isAdmin, form, error, onChange, onSave, onClose }) {
  const title = editId
    ? (isAdmin ? 'Sửa sinh viên' : 'Cập nhật thông tin')
    : 'Thêm sinh viên mới';

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={(e) => e.stopPropagation()}>
        <h3>{title}</h3>
        <form onSubmit={onSave}>
          <div className="form-group">
            <label>Mã sinh viên *</label>
            <input name="studentCode" value={form.studentCode} onChange={onChange}
              disabled={!!editId} required />
          </div>
          <div className="form-group">
            <label>Họ và tên *</label>
            <input name="fullName" value={form.fullName} onChange={onChange}
              disabled={!isAdmin && !!editId} required />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Lớp</label>
              <input name="className" value={form.className} onChange={onChange}
                disabled={!isAdmin && !!editId} />
            </div>
            <div className="form-group">
              <label>Ngày sinh</label>
              <input type="date" name="dateOfBirth" value={form.dateOfBirth} onChange={onChange}
                disabled={!isAdmin && !!editId} />
            </div>
          </div>
          <div className="form-group">
            <label>Ngành học</label>
            <input name="major" value={form.major} onChange={onChange}
              disabled={!isAdmin && !!editId} placeholder="Ví dụ: Công nghệ thông tin" />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Điện thoại</label>
              <input name="phone" value={form.phone} onChange={onChange} />
            </div>
            <div className="form-group">
              <label>Địa chỉ</label>
              <input name="address" value={form.address} onChange={onChange} />
            </div>
          </div>

          {error && <p className="error-msg">{error}</p>}
          <div className="modal-actions">
            <button type="button" className="btn-cancel" onClick={onClose}>Hủy</button>
            <button type="submit" className="btn-primary">{editId ? 'Cập nhật' : 'Thêm mới'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default StudentModal;
