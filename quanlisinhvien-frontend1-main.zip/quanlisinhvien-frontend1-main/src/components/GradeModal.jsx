import React from 'react';

function GradeModal({ student, isAdmin, newSubject, onSubjectChange, onAddSubject, onUpdateGrade, onDeleteGrade, onClose }) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" style={{ maxWidth: '640px' }} onClick={(e) => e.stopPropagation()}>
        <h3>
          Điểm của {student.fullName}
          <span style={{ fontSize: '13px', fontWeight: 400, color: '#6b7280', marginLeft: '6px' }}>
            ({student.studentCode})
          </span>
        </h3>

        {isAdmin && (
          <div style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
            <input
              type="text"
              placeholder="Nhập tên môn học..."
              value={newSubject}
              onChange={(e) => onSubjectChange(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && onAddSubject()}
              style={{
                flex: 1, padding: '8px 10px', border: '1px solid #d1d5db',
                borderRadius: '6px', fontSize: '13px', fontFamily: 'inherit', outline: 'none',
              }}
            />
            <button type="button" className="btn-primary" onClick={onAddSubject}>Thêm môn</button>
          </div>
        )}

        <table className="student-table">
          <thead>
            <tr>
              <th>Môn học</th>
              <th>Điểm</th>
              {isAdmin && <th>Xóa</th>}
            </tr>
          </thead>
          <tbody>
            {(!student.grades || student.grades.length === 0) ? (
              <tr>
                <td colSpan={isAdmin ? 3 : 2} style={{ textAlign: 'center', color: '#9ca3af', padding: '20px' }}>
                  Chưa có môn học nào.
                </td>
              </tr>
            ) : (
              student.grades.map((grade) => (
                <tr key={grade.id}>
                  <td>{grade.subjectName}</td>
                  <td>
                    {isAdmin ? (
                      <input
                        type="number" min="0" max="10" step="0.1"
                        value={grade.score ?? ''}
                        onChange={(e) => {
                          const val = e.target.value;
                          if (val === '' || val === '-') return;
                          const num = parseFloat(val);
                          if (!isNaN(num)) onUpdateGrade(grade, num);
                        }}
                        className="score-input"
                      />
                    ) : (
                      <span style={{ fontWeight: 500 }}>
                        {grade.score != null ? Number(grade.score).toFixed(1) : '—'}
                      </span>
                    )}
                  </td>
                  {isAdmin && (
                    <td>
                      <button type="button" className="btn-delete" onClick={() => onDeleteGrade(grade.id)}>
                        Xóa
                      </button>
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>

        <div className="modal-actions" style={{ marginTop: '16px' }}>
          <button type="button" className="btn-cancel" onClick={onClose}>Đóng</button>
        </div>
      </div>
    </div>
  );
}

export default GradeModal;
