import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getStudents, createStudent, updateStudent, deleteStudent, addStudentGrade, updateGrade, deleteGrade } from '../api/studentApi';
import StudentTable from '../components/StudentTable';
import StudentModal from '../components/StudentModal';
import GradeModal from '../components/GradeModal';

const emptyForm = () => ({ studentCode: '', fullName: '', phone: '', address: '', className: '', dateOfBirth: '', major: '' });

function StudentList() {
  const navigate  = useNavigate();
  const username  = localStorage.getItem('username') || '';
  const role      = localStorage.getItem('role') || '';
  const isAdmin   = role === 'ADMIN';

  const [students, setStudents]               = useState([]);
  const [searchTerm, setSearchTerm]           = useState('');
  const [loading, setLoading]                 = useState(true);
  const [error, setError]                     = useState('');

  // Modal sinh viên
  const [showModal, setShowModal]             = useState(false);
  const [editId, setEditId]                   = useState(null);
  const [form, setForm]                       = useState(emptyForm());

  // Modal điểm
  const [showGradeModal, setShowGradeModal]   = useState(false);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [newSubject, setNewSubject]           = useState('');

  // ── FETCH ──────────────────────────────────────────────
  const fetchStudents = async () => {
    try {
      setLoading(true);
      const res = await getStudents();
      setStudents(res.data);
      if (selectedStudent) {
        const updated = res.data.find(s => s.id === selectedStudent.id);
        if (updated) setSelectedStudent(updated);
      }
    } catch {
      setError('Không thể tải danh sách sinh viên.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchStudents(); }, []);

  // ── SINH VIÊN ──────────────────────────────────────────
  const openAdd  = () => { setEditId(null); setForm(emptyForm()); setShowModal(true); };
  const openEdit = (sv) => {
    setEditId(sv.id);
    setForm({ studentCode: sv.studentCode, fullName: sv.fullName, phone: sv.phone || '', address: sv.address || '', className: sv.className || '', dateOfBirth: sv.dateOfBirth || '', major: sv.major || '' });
    setShowModal(true);
  };
  const closeModal = () => { setShowModal(false); setError(''); };

  const handleSave = async (e) => {
    e.preventDefault(); setError('');
    try {
      editId ? await updateStudent(editId, form) : await createStudent(form);
      closeModal(); fetchStudents();
    } catch (err) {
      const msg = err.response?.data;
      setError(typeof msg === 'string' ? msg : 'Có lỗi xảy ra!');
    }
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Xóa sinh viên "${name}"?`)) return;
    try {
      await deleteStudent(id); fetchStudents();
    } catch (err) {
      alert('Xóa thất bại! ' + (err.response?.data || err.message));
    }
  };

  // ── ĐIỂM ───────────────────────────────────────────────
  const openGradeModal  = (sv) => { setSelectedStudent(sv); setShowGradeModal(true); setNewSubject(''); };
  const closeGradeModal = () => { setShowGradeModal(false); setSelectedStudent(null); };

  const handleAddSubject = async () => {
    if (!newSubject.trim()) return;
    try {
      await addStudentGrade(selectedStudent.id, { subjectName: newSubject, score: null });
      setNewSubject(''); fetchStudents();
    } catch (err) { alert('Thêm môn thất bại: ' + err.message); }
  };

  const handleUpdateGrade = async (grade, value) => {
    value = Math.min(10, Math.max(0, Math.round(value * 10) / 10));
    try {
      await updateGrade(grade.id, { ...grade, score: value }); fetchStudents();
    } catch (err) {
      alert('Sửa điểm thất bại: ' + (err.response?.data || err.message));
    }
  };

  const handleDeleteGrade = async (gradeId) => {
    if (!window.confirm('Xóa môn học này?')) return;
    try {
      await deleteGrade(gradeId); fetchStudents();
    } catch (err) { alert('Xóa môn thất bại: ' + err.message); }
  };

  // ── RENDER ─────────────────────────────────────────────
  const filtered = isAdmin
    ? students.filter(sv =>
        sv.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sv.studentCode.toLowerCase().includes(searchTerm.toLowerCase()))
    : students;

  return (
    <div>
      <header className="app-header">
        <span className="header-title">Quản lý Sinh viên</span>
        <div className="header-right">
          <span>{username} &middot; {role}</span>
          <button className="btn-logout" onClick={() => { localStorage.clear(); navigate('/login'); }}>Đăng xuất</button>
        </div>
      </header>

      <div className="content">
        <div className="toolbar">
          <h2>{isAdmin ? 'Danh sách Sinh viên' : 'Thông tin của tôi'}</h2>
          {isAdmin && (
            <div style={{ display: 'flex', gap: '8px' }}>
              <input type="text" placeholder="Tìm theo mã hoặc tên..." className="search-input"
                value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
              <button className="btn-primary" onClick={openAdd}>+ Thêm sinh viên</button>
            </div>
          )}
        </div>

        {error && !showModal && <p className="error-msg">{error}</p>}

        {loading
          ? <p style={{ color: '#9ca3af', padding: '20px 0' }}>Đang tải...</p>
          : <StudentTable students={filtered} searchTerm={searchTerm} isAdmin={isAdmin}
              onEdit={openEdit} onDelete={handleDelete} onGrade={openGradeModal} />
        }
      </div>

      {showModal && (
        <StudentModal editId={editId} isAdmin={isAdmin} form={form} error={error}
          onChange={(e) => setForm({ ...form, [e.target.name]: e.target.value })}
          onSave={handleSave} onClose={closeModal} />
      )}

      {showGradeModal && selectedStudent && (
        <GradeModal student={selectedStudent} isAdmin={isAdmin}
          newSubject={newSubject} onSubjectChange={setNewSubject}
          onAddSubject={handleAddSubject} onUpdateGrade={handleUpdateGrade}
          onDeleteGrade={handleDeleteGrade} onClose={closeGradeModal} />
      )}
    </div>
  );
}

export default StudentList;